/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2017                    */
/* Created on:     1/22/2023 9:03:14 AM                         */
/*==============================================================*/


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('RIDE') and o.name = 'FK_RIDE_RIDE_END__STATION')
alter table RIDE
   drop constraint FK_RIDE_RIDE_END__STATION
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('RIDE') and o.name = 'FK_RIDE_RIDE_STAR_STATION')
alter table RIDE
   drop constraint FK_RIDE_RIDE_STAR_STATION
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('RIDE') and o.name = 'FK_RIDE_USER_RIDE_USER')
alter table RIDE
   drop constraint FK_RIDE_USER_RIDE_USER
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('SCHEDULE') and o.name = 'FK_SCHEDULE_STATION_S_STATION')
alter table SCHEDULE
   drop constraint FK_SCHEDULE_STATION_S_STATION
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('USER_FAV_STATIONS') and o.name = 'FK_USER_FAV_USER_FAV__STATION')
alter table USER_FAV_STATIONS
   drop constraint FK_USER_FAV_USER_FAV__STATION
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('USER_FAV_STATIONS') and o.name = 'FK_USER_FAV_USER_FAV__USER')
alter table USER_FAV_STATIONS
   drop constraint FK_USER_FAV_USER_FAV__USER
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('RIDE')
            and   name  = 'RIDE_END_ST_FK'
            and   indid > 0
            and   indid < 255)
   drop index RIDE.RIDE_END_ST_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('RIDE')
            and   name  = 'RIDE_START_ST_FK'
            and   indid > 0
            and   indid < 255)
   drop index RIDE.RIDE_START_ST_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('RIDE')
            and   name  = 'USER_RIDES_FK'
            and   indid > 0
            and   indid < 255)
   drop index RIDE.USER_RIDES_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('RIDE')
            and   type = 'U')
   drop table RIDE
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('SCHEDULE')
            and   name  = 'STATION_SCHEDULES_FK'
            and   indid > 0
            and   indid < 255)
   drop index SCHEDULE.STATION_SCHEDULES_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('SCHEDULE')
            and   type = 'U')
   drop table SCHEDULE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('STATION')
            and   type = 'U')
   drop table STATION
go

if exists (select 1
            from  sysobjects
           where  id = object_id('"USER"')
            and   type = 'U')
   drop table "USER"
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('USER_FAV_STATIONS')
            and   name  = 'USER_FAV_STATIONS_FK'
            and   indid > 0
            and   indid < 255)
   drop index USER_FAV_STATIONS.USER_FAV_STATIONS_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('USER_FAV_STATIONS')
            and   name  = 'USER_FAV_STATIONS2_FK'
            and   indid > 0
            and   indid < 255)
   drop index USER_FAV_STATIONS.USER_FAV_STATIONS2_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('USER_FAV_STATIONS')
            and   type = 'U')
   drop table USER_FAV_STATIONS
go

/*==============================================================*/
/* Table: RIDE                                                  */
/*==============================================================*/
create table RIDE (
   RIDE_ID              int                  not null,
   USER_ID              int                  not null,
   ST_FROM_ID           int                  not null,
   ST_TO_ID             int                  not null,
   FROM_ADDRESS         text                 not null,
   TO_ADDRESS           text                 not null,
   RIDE_DATE            datetime             not null,
   NOTES                text                 null,
   constraint PK_RIDE primary key (RIDE_ID)
)
go

/*==============================================================*/
/* Index: USER_RIDES_FK                                         */
/*==============================================================*/




create nonclustered index USER_RIDES_FK on RIDE (USER_ID ASC)
go

/*==============================================================*/
/* Index: RIDE_START_ST_FK                                      */
/*==============================================================*/




create nonclustered index RIDE_START_ST_FK on RIDE (ST_FROM_ID ASC)
go

/*==============================================================*/
/* Index: RIDE_END_ST_FK                                        */
/*==============================================================*/




create nonclustered index RIDE_END_ST_FK on RIDE (ST_TO_ID ASC)
go

/*==============================================================*/
/* Table: SCHEDULE                                              */
/*==============================================================*/
create table SCHEDULE (
   SCHEDULE_ID          int                  not null,
   ST_ID                int                  not null,
   DATETIME             datetime             not null,
   TYPE                 char(15)             not null,
   ACTIVE               bit                  not null,
   constraint PK_SCHEDULE primary key (SCHEDULE_ID)
)
go

/*==============================================================*/
/* Index: STATION_SCHEDULES_FK                                  */
/*==============================================================*/




create nonclustered index STATION_SCHEDULES_FK on SCHEDULE (ST_ID ASC)
go

/*==============================================================*/
/* Table: STATION                                               */
/*==============================================================*/
create table STATION (
   ST_ID                int                  not null,
   ST_SCHEDULE_IDS      int                  not null,
   ST_SEQUENCE          int                  not null,
   ST_NAME              char(40)             not null,
   constraint PK_STATION primary key (ST_ID)
)
go

/*==============================================================*/
/* Table: "USER"                                                */
/*==============================================================*/
create table "USER" (
   USER_ID              int                  not null,
   US_NAME              char(30)             not null,
   US_LASTNAME          char(30)             not null,
   US_EMAIL             char(50)             not null,
   US_PHONE             numeric              not null,
   US_ADDRESS           text                 not null,
   US_FAVORITE_STATION_IDS int                  null,
   US_RIDE_IDS          int                  null,
   constraint PK_USER primary key (USER_ID)
)
go

/*==============================================================*/
/* Table: USER_FAV_STATIONS                                     */
/*==============================================================*/
create table USER_FAV_STATIONS (
   ST_ID                int                  not null,
   USER_ID              int                  not null,
   constraint PK_USER_FAV_STATIONS primary key (ST_ID, USER_ID)
)
go

/*==============================================================*/
/* Index: USER_FAV_STATIONS2_FK                                 */
/*==============================================================*/




create nonclustered index USER_FAV_STATIONS2_FK on USER_FAV_STATIONS (USER_ID ASC)
go

/*==============================================================*/
/* Index: USER_FAV_STATIONS_FK                                  */
/*==============================================================*/




create nonclustered index USER_FAV_STATIONS_FK on USER_FAV_STATIONS (ST_ID ASC)
go

alter table RIDE
   add constraint FK_RIDE_RIDE_END__STATION foreign key (ST_TO_ID)
      references STATION (ST_ID)
go

alter table RIDE
   add constraint FK_RIDE_RIDE_STAR_STATION foreign key (ST_FROM_ID)
      references STATION (ST_ID)
go

alter table RIDE
   add constraint FK_RIDE_USER_RIDE_USER foreign key (USER_ID)
      references "USER" (USER_ID)
go

alter table SCHEDULE
   add constraint FK_SCHEDULE_STATION_S_STATION foreign key (ST_ID)
      references STATION (ST_ID)
go

alter table USER_FAV_STATIONS
   add constraint FK_USER_FAV_USER_FAV__STATION foreign key (ST_ID)
      references STATION (ST_ID)
go

alter table USER_FAV_STATIONS
   add constraint FK_USER_FAV_USER_FAV__USER foreign key (USER_ID)
      references "USER" (USER_ID)
go

